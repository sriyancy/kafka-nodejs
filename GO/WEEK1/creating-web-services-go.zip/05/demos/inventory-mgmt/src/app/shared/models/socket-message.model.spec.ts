import { ISocketMessage } from './socket-message.model';

describe('ISocketMessage', () => {
  it('should create an instance', () => {
    expect(new ISocketMessage()).toBeTruthy();
  });
});
