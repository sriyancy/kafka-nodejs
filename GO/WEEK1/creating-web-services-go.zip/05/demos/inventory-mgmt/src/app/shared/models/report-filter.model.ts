export interface IReportFilter {
    sku: string;
    manufacturer: string;
    productName: string;
}
