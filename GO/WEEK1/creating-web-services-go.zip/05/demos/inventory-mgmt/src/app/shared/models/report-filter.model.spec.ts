import { IReportFilter } from './report-filter.model';

describe('IReportFilter', () => {
  it('should create an instance', () => {
    expect(new IReportFilter()).toBeTruthy();
  });
});
