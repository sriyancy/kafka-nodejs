export interface IReceipt {
    name: string;
    uploadDate: Date;
}
