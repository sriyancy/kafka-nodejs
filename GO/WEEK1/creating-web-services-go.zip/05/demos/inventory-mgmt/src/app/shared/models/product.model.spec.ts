import { IProduct } from './product.model';

describe('IProduct', () => {
  it('should create an instance', () => {
    expect(new IProduct()).toBeTruthy();
  });
});
