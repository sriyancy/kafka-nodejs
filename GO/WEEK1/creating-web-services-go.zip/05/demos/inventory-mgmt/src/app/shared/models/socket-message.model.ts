export interface ISocketMessage {
    data: any;
}
