import { IReceipt } from './receipt.model';

describe('IReceipt', () => {
  it('should create an instance', () => {
    expect(new IReceipt()).toBeTruthy();
  });
});
