export interface IReceipt {
    receiptId: string;
    name: string;
    uploadDate: Date;
}
