import { Receipt.Model } from './receipt.model';

describe('Receipt.Model', () => {
  it('should create an instance', () => {
    expect(new Receipt.Model()).toBeTruthy();
  });
});
