export interface IReportFilter {
    skuFilter: string;
    manufacturerFilter: string;
    productFilter: string;
}
