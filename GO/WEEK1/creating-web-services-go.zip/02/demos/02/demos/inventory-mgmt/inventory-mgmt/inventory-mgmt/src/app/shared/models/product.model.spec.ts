import { Product.Model } from './product.model';

describe('Product.Model', () => {
  it('should create an instance', () => {
    expect(new Product.Model()).toBeTruthy();
  });
});
