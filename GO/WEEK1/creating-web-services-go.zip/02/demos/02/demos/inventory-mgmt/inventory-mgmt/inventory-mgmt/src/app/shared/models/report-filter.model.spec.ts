import { ReportFilter.Model } from './report-filter.model';

describe('ReportFilter.Model', () => {
  it('should create an instance', () => {
    expect(new ReportFilter.Model()).toBeTruthy();
  });
});
