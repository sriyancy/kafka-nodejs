package main

func main() {
	for i := 1; i < 5; i++ {
		println(i)
	}
}
