package main

func main() {
	println("Starting web server")

	// do important things
	panic("Something bad just happened")

	println("Web server started")
}
