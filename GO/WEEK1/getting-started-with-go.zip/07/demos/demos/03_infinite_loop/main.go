package main

func main() {
	var i int
	for {
		println(i)
		i++
		if i >= 5 {
			break
		}
	}
}
