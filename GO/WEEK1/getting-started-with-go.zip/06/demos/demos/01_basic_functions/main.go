package main

import (
	"fmt"
)

func main() {
	fmt.Println("Hello, playground")
	startWebServer()
}

func startWebServer() {
	println("Starting server...")
	// do important things
	println("Server started")
}