package main

func main() {
	const c int = 3
	println(c + 1.2)

	// a bunch of code

	println(c + 5)
}
