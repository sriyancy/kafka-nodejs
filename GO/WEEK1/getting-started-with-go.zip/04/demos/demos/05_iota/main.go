package main

const (
	first = iota
	second
)

const (
	third = iota
	fourth
)

func main() {
	println(first, second, third, fourth)
}
